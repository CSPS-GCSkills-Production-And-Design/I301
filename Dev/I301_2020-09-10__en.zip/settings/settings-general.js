'use strict';

define({


	/*------------------ Course info -----------------*/
	courseLegacyCode:"I301",
	courseTitle_en: "Fundamentals of Information Management",
	courseTitle_fr: "Principes fondamentaux de la gestion de l’information",
	courseSubtitle_en: "",
	courseSubtitle_fr: "",
	seriesTitle_en: 	 "",
	seriesTitle_fr: 	 "",

	showSitemap: true,

	showGlossary: true,

	trackAllPages: true,
	triggerCompletionWhenAllPagesViewed: false,
	
	googleAnalyticsID: "UA-101907595-16"
});